# ziplabs
Simple mock to demonstrate my ability to create pixel perfect page layouts using CSS/Bootstrap

## TODO
* Would like to get the colors exact to the mock I was given
* Would make the navbar collapse more seamlessly 
* Would get the margins/padding to be more exact for several elements
